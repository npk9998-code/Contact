#!/bin/bash
# تشغيل سريع لمشروع هاتف — نفّذه داخل مجلد backend
# الاستخدام: bash setup.sh

set -e

echo "📦 تثبيت المكتبات..."
npm install

if [ -f ".env.READY" ]; then
  echo "🔧 تفعيل ملف الإعدادات..."
  mv .env.READY .env
fi

echo "🗄️  إنشاء جداول قاعدة البيانات..."
npx prisma migrate dev --name init

echo "🌱 إدخال البيانات التجريبية..."
node prisma/seed.js

echo "🚀 تشغيل السيرفر..."
npm run dev
